
package Dibujos;
public class Guitarra {
    // Atributos
    String marca;
    String tipo; // Eléctrica, acústica, etc.
    int cuerdas;
    String color;
    boolean afinada;

    // Constructor
    public Guitarra(String marca, String tipo, int cuerdas, String color, boolean afinada) {
        this.marca = marca;
        this.tipo = tipo;
        this.cuerdas = cuerdas;
        this.color = color;
        this.afinada = afinada;
    }

    // Métodos
    public void afinar() {
        afinada = true;
        System.out.println("La guitarra ha sido afinada.");
    }

    public void tocar() {
        System.out.println("Estás tocando la guitarra " + marca + " (" + tipo + ").");
    }

    public void cambiarCuerda(int numero) {
        System.out.println("Cuerda número " + numero + " reemplazada.");
    }

    public void mostrarDetalles() {
        System.out.println(marca + " - " + tipo + " - " + color + " - " + cuerdas + " cuerdas");
    }

    public void limpiar() {
        System.out.println("La guitarra ha sido limpiada.");
    }

    // Getters y Setters
    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getCuerdas() { return cuerdas; }
    public void setCuerdas(int cuerdas) { this.cuerdas = cuerdas; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public boolean isAfinada() { return afinada; }
    public void setAfinada(boolean afinada) { this.afinada = afinada; }
}


