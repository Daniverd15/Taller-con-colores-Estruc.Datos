
package Dibujos;

public class Computador {

    String marca;
    String procesador;
    int memoriaRAM;
    int almacenamiento;
    String sistemaOperativo;

    public Computador(String marca, String procesador, int memoriaRAM, int almacenamiento, String sistemaOperativo) {
        this.marca = marca;
        this.procesador = procesador;
        this.memoriaRAM = memoriaRAM;
        this.almacenamiento = almacenamiento;
        this.sistemaOperativo = sistemaOperativo;
    }

    public void encender() {
        System.out.println("El computador " + marca + " está encendido.");
    }

    public void apagar() {
        System.out.println("El computador se está apagando...");
    }

    public void ejecutarPrograma(String programa) {
        System.out.println("Ejecutando " + programa + " en " + sistemaOperativo + ".");
    }

    public void mostrarEspecificaciones() {
        System.out.println(marca + ", " + procesador + ", " + memoriaRAM + "GB RAM, " + almacenamiento + "GB, " + sistemaOperativo);
    }

    public void actualizarSO(String nuevoSO) {
        this.sistemaOperativo = nuevoSO;
        System.out.println("Sistema operativo actualizado a: " + nuevoSO);
    }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getProcesador() { return procesador; }
    public void setProcesador(String procesador) { this.procesador = procesador; }

    public int getMemoriaRAM() { return memoriaRAM; }
    public void setMemoriaRAM(int memoriaRAM) { this.memoriaRAM = memoriaRAM; }

    public int getAlmacenamiento() { return almacenamiento; }
    public void setAlmacenamiento(int almacenamiento) { this.almacenamiento = almacenamiento; }

    public String getSistemaOperativo() { return sistemaOperativo; }
    public void setSistemaOperativo(String sistemaOperativo) { this.sistemaOperativo = sistemaOperativo; }
}
