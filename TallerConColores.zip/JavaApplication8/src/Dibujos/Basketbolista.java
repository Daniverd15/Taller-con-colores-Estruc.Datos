
package Dibujos;

public class Basketbolista {

    String nombre;
    int edad;
    double estatura;
    String equipo;
    int numeroCamiseta;
    public Basketbolista(String nombre, int edad, double estatura, String equipo, int numeroCamiseta) {
        this.nombre = nombre;
        this.edad = edad;
        this.estatura = estatura;
        this.equipo = equipo;
        this.numeroCamiseta = numeroCamiseta;
    }
    public void entrenar() {
        System.out.println(nombre + " está entrenando.");
    }

    public void lanzarBalon() {
        System.out.println(nombre + " lanza el balón al aro.");
    }

    public void hacerPase() {
        System.out.println(nombre + " hace un pase a un compañero.");
    }

    public void anotarPuntos(int puntos) {
        System.out.println(nombre + " anotó " + puntos + " puntos.");
    }

    public void mostrarPerfil() {
        System.out.println("Jugador: " + nombre + ", Equipo: " + equipo + ", Camiseta #" + numeroCamiseta);
    }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public double getEstatura() { return estatura; }
    public void setEstatura(double estatura) { this.estatura = estatura; }

    public String getEquipo() { return equipo; }
    public void setEquipo(String equipo) { this.equipo = equipo; }

    public int getNumeroCamiseta() { return numeroCamiseta; }
    public void setNumeroCamiseta(int numeroCamiseta) { this.numeroCamiseta = numeroCamiseta; }
}    
