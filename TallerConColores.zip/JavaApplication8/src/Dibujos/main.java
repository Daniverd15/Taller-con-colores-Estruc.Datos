
package Dibujos;

public class main {
    public static void main(String[] args) {
        Basketbolista jugador = new Basketbolista("Daniel Pérez", 24, 1.92, "Lakers", 12);
        Computador pc = new Computador("Dell", "Intel Core i5", 16, 512, "Windows 11");
        Guitarra guitarra = new Guitarra("Fender", "Eléctrica", 6, "Rojo", false);

        
        jugador.entrenar();
        pc.ejecutarPrograma("Visual Studio Code");
        guitarra.afinar();

        System.out.println("Nombre del basquetbolista: " + jugador.getNombre());
        System.out.println("Marca del computador: " + pc.getMarca());
        System.out.println("Color de la guitarra: " + guitarra.getColor());
    }
}
